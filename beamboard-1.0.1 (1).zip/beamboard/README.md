# BeamBoard

**Presentazioni LaTeX guidate, senza conoscere LaTeX.**

BeamBoard crea presentazioni Beamer con una procedura guidata in italiano: si sceglie che cosa mostrare (alcuni punti, un confronto, una foto, una formula…), si risponde a qualche domanda e la slide si compone da sola, con un’anteprima vera del PDF finale.

Tutto avviene nel browser: il motore LaTeX gira sul computer di chi la usa, i testi e le immagini non vengono inviati da nessuna parte, e dopo la prima apertura funziona anche senza internet. Funziona al meglio con Chrome, Edge, Vivaldi o Brave.

## Cosa sa fare

- Dodici tipi di slide, ognuno con la sua procedura guidata, riapribile in qualsiasi momento.
- Elementi da combinare: testi, elenchi (anche a comparsa), immagini, riquadri, tabelle, citazioni e formule.
- Un editor visuale per le formule, con tastiera di simboli in italiano.
- Otto temi, sette colori, cinque caratteri, formato 16:9 o 4:3.
- Salvataggio automatico su un file `.beamboard` del computer.
- Installabile come applicazione e utilizzabile offline.

## Come è fatta la cartella

| Percorso | Contenuto |
|---|---|
| `index.html` | BeamBoard |
| `aiuto.html`, `crediti.html` | Guida e crediti |
| `css/`, `js/`, `img/` | Stili, codice dell’interfaccia e del generatore di slide, icone e anteprime dei temi |
| `engine/` | Il motore LaTeX (SwiftLaTeX modificato) e il pacchetto compresso dei file TeX |
| `vendor/` | PDF.js e MathLive |
| `sw.js`, `manifest.webmanifest` | Funzionamento offline e installazione |

## Pubblicarla con GitHub Pages

Si fa tutto dal sito di GitHub, senza terminale.

1. **Crea il repository.** Su github.com premi il **+** in alto a destra, poi *New repository*. Chiamalo per esempio `beamboard`, lascialo *Public* e non aggiungere nessun file. Premi *Create repository*.
2. **Carica i file.** Nella pagina del repository vuoto, premi il collegamento *uploading an existing file*. Trascina nella pagina **il contenuto** della cartella `beamboard`, cioè file e sottocartelle, non la cartella stessa. Aspetta che il caricamento finisca e premi *Commit changes*.
3. **Attiva il sito.** Vai su *Settings*, poi *Pages* nel menu a sinistra. In *Build and deployment* scegli *Deploy from a branch*, il ramo `main` e la cartella `/ (root)`, poi *Save*.
4. **Aspetta un paio di minuti.** In cima alla stessa pagina compare l’indirizzo del sito, del tipo `https://nomeutente.github.io/beamboard/`.

Il caricamento dal sito di GitHub accetta file fino a 25 MB: il pacchetto dei file TeX in `engine/` ci sta, di poco.

## Aggiornarla

Quando arriva una versione nuova, carica i file nuovi con *Add file → Upload files*, sovrascrivendo quelli vecchi. Se nella cartella `engine/` il pacchetto `tex-….bin.gz` ha cambiato nome, elimina quello vecchio. Chi sta già usando BeamBoard vedrà un avviso con il pulsante *Aggiorna ora*.

## Licenza

BeamBoard è software libero, distribuito con licenza **GNU Affero General Public License v3.0**: vedi il file `LICENSE`. Il motore LaTeX deriva da [SwiftLaTeX](https://github.com/SwiftLaTeX/SwiftLaTeX), anch’esso AGPL-3.0. Gli altri componenti e i caratteri hanno licenze libere compatibili, elencate in `crediti.html`.
